//
// Created by bytedance on 2022/5/1.
//

#include "MyFormat.h"
